<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

//$config['appId']	= '484657384969547';
//$config['secret']	= 'b9e0c220d2f3d1941cfcabc9b1bb6e20';

/**
 * Display Name: Test; 
 * Namespace:adiyyatest; 
 * Contact Email:adiyya@gmail.com
 */
$config['appId']	= '81544321695'; 
$config['secret']	= '55f1f3958bb291c6ab30b37e00499376';


/* End of file facebook.php */
/* Location: ./application/config/facebook.php */

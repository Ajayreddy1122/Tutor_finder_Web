<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$config['twitter_consumer_token']		= 'OcIgtWdHJqcZuOgcBlmrIqejm';
$config['twitter_consumer_secret']		= 'ryOOnZrNURcmER3mcodmtN812Mq0lZD0qV7JC7SnVkJsAVgOG6';
$config['twitter_access_token']			= '106636064-qW0z8XHxeN715jfRng7kzrriax2i9yDFwCIBbg3c'; // Optional
$config['twitter_access_secret']		= 'mzTV5FK190HwrP3tGrmgxvF7x2h1zWkgGdWXql7Sfegbb'; // Optional

/* End of file twitter.php */
/* Location: ./application/config/twitter.php */
<?php

class Services_Twilio_Rest_TaskRouter_Worker extends Services_Twilio_TaskRouterInstanceResource {

}
